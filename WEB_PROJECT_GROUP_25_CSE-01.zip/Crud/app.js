const express = require("express");
const mongoose = require("mongoose");
const path = require("path");
const multer = require("multer");
const Product = require("./models/Product"); // Assuming you have a Product model
const app = express();

// Middleware to serve static files (like images)
app.use(express.static(path.join(__dirname, 'public')));

// Connect to MongoDB
mongoose.connect("mongodb://localhost:27017/your-db-name", {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

// Product Schema (Example)
const productSchema = new mongoose.Schema({
  name: String,
  price: Number,
  description: String,
  image: String,
});

const Product = mongoose.model("Product", productSchema);

// Route to fetch all products
app.get("/products", async (req, res) => {
  try {
    const products = await Product.find();
    res.json(products);
  } catch (error) {
    res.status(500).send("Error fetching products");
  }
});

// Route to handle adding a product
const upload = multer({ dest: 'public/uploads/' }); // Upload images to public/uploads folder
app.post("/products", upload.single("image"), async (req, res) => {
  try {
    const { name, price, description } = req.body;
    const image = req.file ? req.file.filename : null; // Save image filename if uploaded

    const newProduct = new Product({
      name,
      price,
      description,
      image,
    });

    await newProduct.save();
    res.status(201).send("Product added successfully");
  } catch (error) {
    res.status(500).send("Error adding product");
  }
});

// Route to delete a product
app.delete("/products/:id", async (req, res) => {
  try {
    await Product.findByIdAndDelete(req.params.id);
    res.status(200).send("Product deleted successfully");
  } catch (error) {
    res.status(500).send("Error deleting product");
  }
});

// Start the server
app.listen(3000, () => {
  console.log("Server running on port 3000");
});
